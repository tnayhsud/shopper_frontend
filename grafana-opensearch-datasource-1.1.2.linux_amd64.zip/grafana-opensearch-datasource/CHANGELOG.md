# Change Log

All notable changes to this project will be documented in this file.
## v1.1.2
### Bug fixes
- Improve error handling
- Fix alias pattern not being correctly handled by Query Editor

## v1.1.0

### New features

- Add support for Elasticsearch databases (2f9e802)

## v1.0.0

- First Release
